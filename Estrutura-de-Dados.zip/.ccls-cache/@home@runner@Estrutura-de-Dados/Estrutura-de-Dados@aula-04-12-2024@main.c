#include <stdio.h>

typedef struct{
  int dado;
  struct elemento *prox;
}*PILHA;


